# Dodge Aeris — 3D Camera Prototype

เปิด index.html ใน Chrome (ต้องใช้อินเทอร์เน็ตเพื่อโหลด Three.js)

WASD เดิน, ลากบนฉากหมุนกล้อง, Scroll ซูม, เลือก Free / Fixed / Follow.

นี่เป็นต้นแบบทดสอบ ยังไม่มีระบบล็อกอิน อุปกรณ์ หรือเซิร์ฟเวอร์ และยังไม่ได้อัปโหลด GitHub
